-- main.lua

-- Variables pour le menu
local menuOptions = {"Start Game", "Options", "Exit"}
local selectedOption = 1

-- Fonction d'initialisation
function love.load()
    love.graphics.setBackgroundColor(0.2, 0.2, 0.2)
    love.graphics.setFont(love.graphics.newFont(30))
end

-- Fonction de mise à jour
function love.update(dt)
    -- Navigation du menu avec les flèches haut et bas
    if love.keyboard.isDown("up") then
        selectedOption = selectedOption - 1
        if selectedOption < 1 then
            selectedOption = #menuOptions
        end
        love.timer.sleep(0.15)  -- Petite pause pour éviter un défilement trop rapide
    elseif love.keyboard.isDown("down") then
        selectedOption = selectedOption + 1
        if selectedOption > #menuOptions then
            selectedOption = 1
        end
        love.timer.sleep(0.15)  -- Petite pause pour éviter un défilement trop rapide
    end
end

-- Fonction d'affichage
function love.draw()
    -- Afficher le titre du menu
    love.graphics.setColor(1, 1, 1)
    love.graphics.printf("Main Menu", 0, 100, love.graphics.getWidth(), "center")

    --
-- main.lua

-- Variables pour le menu
local menuOptions = {"Start Game", "Options", "Exit"}
local selectedOption = 1

-- Fonction d'initialisation
function love.load()
    love.graphics.setBackgroundColor(0.2, 0.2, 0.2)
    love.graphics.setFont(love.graphics.newFont(30))
end

-- Fonction de mise à jour
function love.update(dt)
    -- Navigation du menu avec les flèches haut et bas
    if love.keyboard.isDown("up") then
        selectedOption = selectedOption - 1
        if selectedOption < 1 then
            selectedOption = #menuOptions
        end
        love.timer.sleep(0.15)  -- Petite pause pour éviter un défilement trop rapide
    elseif love.keyboard.isDown("down") then
        selectedOption = selectedOption + 1
        if selectedOption > #menuOptions then
            selectedOption = 1
        end
        love.timer.sleep(0.15)  -- Petite pause pour éviter un défilement trop rapide
    end
end

-- Fonction d'affichage
function love.draw()
    -- Afficher le titre du menu
    love.graphics.setColor(1, 1, 1)
    love.graphics.printf("Main Menu", 0, 100, love.graphics.getWidth(), "center")

    --
-- main.lua

-- Variables pour le menu
local menuOptions = {"Start Game", "Options", "Exit"}
local selectedOption = 1

-- Fonction d'initialisation
function love.load()
    love.graphics.setBackgroundColor(0.2, 0.2, 0.2)
    love.graphics.setFont(love.graphics.newFont(30))
end

-- Fonction de mise à jour
function love.update(dt)
    -- Navigation du menu avec les flèches haut et bas
    if love.keyboard.isDown("up") then
        selectedOption = selectedOption - 1
        if selectedOption < 1 then
            selectedOption = #menuOptions
        end
        love.timer.sleep(0.15)  -- Petite pause pour éviter un défilement trop rapide
    elseif love.keyboard.isDown("down") then
        selectedOption = selectedOption + 1
        if selectedOption > #menuOptions then
            selectedOption = 1
        end
        love.timer.sleep(0.15)  -- Petite pause pour éviter un défilement trop rapide
    end
end

-- Fonction d'affichage
function love.draw()
    -- Afficher le titre du menu
    love.graphics.setColor(1, 1, 1)
    love.graphics.printf("Main Menu", 0, 100, love.graphics.getWidth(), "center")

    --
-- main.lua

-- Variables pour le menu
local menuOptions = {"Start Game", "Options", "Exit"}
local selectedOption = 1

-- Fonction d'initialisation
function love.load()
    love.graphics.setBackgroundColor(0.2, 0.2, 0.2)
    love.graphics.setFont(love.graphics.newFont(30))
end

-- Fonction de mise à jour
function love.update(dt)
    -- Navigation du menu avec les flèches haut et bas
    if love.keyboard.isDown("up") then
        selectedOption = selectedOption - 1
        if selectedOption < 1 then
            selectedOption = #menuOptions
        end
        love.timer.sleep(0.15)  -- Petite pause pour éviter un défilement trop rapide
    elseif love.keyboard.isDown("down") then
        selectedOption = selectedOption + 1
        if selectedOption > #menuOptions then
            selectedOption = 1
        end
        love.timer.sleep(0.15)  -- Petite pause pour éviter un défilement trop rapide
    end
end

-- Fonction d'affichage
function love.draw()
    -- Afficher le titre du menu
    love.graphics.setColor(1, 1, 1)
    love.graphics.printf("Main Menu", 0, 100, love.graphics.getWidth(), "center")

    --
-- main.lua

-- Variables pour le menu
local menuOptions = {"Start Game", "Options", "Exit"}
local selectedOption = 1

-- Fonction d'initialisation
function love.load()
    love.graphics.setBackgroundColor(0.2, 0.2, 0.2)
    love.graphics.setFont(love.graphics.newFont(30))
end

-- Fonction de mise à jour
function love.update(dt)
    -- Navigation du menu avec les flèches haut et bas
    if love.keyboard.isDown("up") then
        selectedOption = selectedOption - 1
        if selectedOption < 1 then
            selectedOption = #menuOptions
        end
        love.timer.sleep(0.15)  -- Petite pause pour éviter un défilement trop rapide
    elseif love.keyboard.isDown("down") then
        selectedOption = selectedOption + 1
        if selectedOption > #menuOptions then
            selectedOption = 1
        end
        love.timer.sleep(0.15)  -- Petite pause pour éviter un défilement trop rapide
    end
end

-- Fonction d'affichage
function love.draw()
    -- Afficher le titre du menu
    love.graphics.setColor(1, 1, 1)
    love.graphics.printf("Main Menu", 0, 100, love.graphics.getWidth(), "center")

    --
-- main.lua

-- Variables pour le menu
local menuOptions = {"Start Game", "Options", "Exit"}
local selectedOption = 1

-- Fonction d'initialisation
function love.load()
    love.graphics.setBackgroundColor(0.2, 0.2, 0.2)
    love.graphics.setFont(love.graphics.newFont(30))
end

-- Fonction de mise à jour
function love.update(dt)
    -- Navigation du menu avec les flèches haut et bas
    if love.keyboard.isDown("up") then
        selectedOption = selectedOption - 1
        if selectedOption < 1 then
            selectedOption = #menuOptions
        end
        love.timer.sleep(0.15)  -- Petite pause pour éviter un défilement trop rapide
    elseif love.keyboard.isDown("down") then
        selectedOption = selectedOption + 1
        if selectedOption > #menuOptions then
            selectedOption = 1
        end
        love.timer.sleep(0.15)  -- Petite pause pour éviter un défilement trop rapide
    end
end

-- Fonction d'affichage
function love.draw()
    -- Afficher le titre du menu
    love.graphics.setColor(1, 1, 1)
    love.graphics.printf("Main Menu", 0, 100, love.graphics.getWidth(), "center")

    --
